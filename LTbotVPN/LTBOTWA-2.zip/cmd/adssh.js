const fs = require('fs');
const { Client } = require('ssh2');

module.exports = async ({ isAdmin, isOwner, args, lunaticreply }) => {
    if (!isAdmin && !isOwner) return lunaticreply("❌ ```KHUSUS LUNATIC``` ");

  // Ambil prefix dari prefix.json
  let prefix = '!';
  try {
    const pf = JSON.parse(fs.readFileSync('./avars/prefix.json'));
    prefix = pf.prefix || '!';
  } catch {}

  // batas ambil Prefix
  const [namaakun, passakun, limitIP, expired, targetVps] = args;
  if (!namaakun || !passakun || !limitIP || !expired || !targetVps) {
    return lunaticreply(
      `❗ *Format Salah!*\n\n*Contoh:*\n${prefix}adssh nama password limitIP expired namaVPS\n\n*Example:*\n${prefix}adssh dian dian123 1 1 ram9`
    );
  }

  const vpsPath = './avars/vpsdata.json';
  if (!fs.existsSync(vpsPath)) return lunaticreply('❌ ```DATA VPS KOSONG```');

  const vpsData = JSON.parse(fs.readFileSync(vpsPath));
  const target = vpsData[targetVps];
  if (!target) {
    return lunaticreply(`❌ VPS "${targetVps}" tidak ditemukan!\nGunakan: *${prefix}listvps*`);
  }

  const conn = new Client();
  conn.on('ready', () => {
    const cmd = `bash /usr/bin/LTBOTVPN/buatSSH ${namaakun} ${passakun} ${limitIP} ${expired}`;
    conn.exec(cmd, (err, stream) => {
      if (err) return lunaticreply('❌ Gagal eksekusi command di VPS');

      let output = '';
      stream.on('data', chunk => output += chunk.toString());
      stream.stderr.on('data', errChunk => output += errChunk.toString());
      stream.on('close', () => {
        conn.end();
        if (!output.trim()) {
          return lunaticreply('⚠️ Tidak ada output. Cek manual di VPS.');
        }

        const beautify = '```' + output.trim() + '```';
        lunaticreply(`✅ *SSH Berhasil dibuat:*\n\n${beautify}`);
      });
    });
  }).on('error', err => {
    lunaticreply(`❌ Gagal konek ke VPS: ${err.message}`);
  }).connect({
    host: target.ip,
    port: 22,
    username: 'root',
    password: target.pass
  });
};
