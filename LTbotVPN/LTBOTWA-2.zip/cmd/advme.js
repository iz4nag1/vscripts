const fs = require('fs');
const { Client } = require('ssh2');

module.exports = async ({ isAdmin, isOwner, args, lunaticreply }) => {
    if (!isAdmin && !isOwner) return lunaticreply("❌ ```KHUSUS LUNATIC``` ");

  // Prefix dinamis
  let prefix = '!';
  try {
    const pf = JSON.parse(fs.readFileSync('./avars/prefix.json'));
    prefix = pf.prefix || '!';
  } catch {}

  const [username, expired, quota, limitIP, targetVps] = args;
  if (!username || !expired || !quota || !limitIP || !targetVps) {
    return lunaticreply(
      `❗ *Format Salah!*\n\n*Contoh:*\n${prefix}advme nama exp quota limitIP namaVPS\n\n*Example:*\n${prefix}advme dian 60 1 1 ram9`
    );
  }

  const vpsPath = './avars/vpsdata.json';
  if (!fs.existsSync(vpsPath)) return lunaticreply('❌ ```DATA VPS KOSONG```');

  const vpsData = JSON.parse(fs.readFileSync(vpsPath));
  const target = vpsData[targetVps];
  if (!target) {
    return lunaticreply(`❌ VPS "${targetVps}" tidak ditemukan!\nGunakan: *${prefix}listvps*`);
  }

  const conn = new Client();
  conn
    .on('ready', () => {
      const cmd = `bash /usr/bin/LTBOTVPN/buatVME ${username} ${expired} ${quota} ${limitIP}`;
      conn.exec(cmd, (err, stream) => {
        if (err) return lunaticreply(`❌ Gagal eksekusi script di VPS`);

        let output = '';
        stream.on('data', (chunk) => (output += chunk.toString()));
        stream.stderr.on('data', (errChunk) => (output += errChunk.toString()));
        stream.on('close', () => {
          conn.end();
          if (!output.trim()) {
            return lunaticreply('⚠️ Tidak ada output dari VPS. Cek manual.');
          }

          // Format blok WhatsApp
          lunaticreply(`✅ *Akun VMESS berhasil dibuat:*\n\n\`\`\`${output.trim()}\`\`\``);
        });
      });
    })
    .on('error', (err) => {
      lunaticreply(`❌ Gagal konek ke VPS: ${err.message}`);
    })
    .connect({
      host: target.ip,
      port: 22,
      username: 'root',
      password: target.pass,
    });
};