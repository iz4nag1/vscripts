/*  
  Base ASLI : lunatic
  WhatsApp : wa.me/6283197765857

*/

//global.admin = ['6283197765857@s.whatsapp.net'] // Sesuaikan Nomor Admin

//global.prefix = '!'

global.image = './image/menu.png'

// Custom Message
global.mess = {
    wait: ' ```wait..🗿```',
    error: ' ```erro🗿``` ',
    default: ' ```Ngetik apa🗿``` ',
    admin: ' ```husus admin🗿``` ',
    group: ' ```husus group🗿``` ',
}